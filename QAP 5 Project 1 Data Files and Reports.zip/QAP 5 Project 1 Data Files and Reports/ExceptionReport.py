# TO BE A PRO--START PLANNING LIKE A PRO
# Raymond Payne
# QAP 5 Project 1B Exceptional Report
# April 02 2023
import FormatValues as FV
import datetime


import FormatValues as FV
import datetime


Today = datetime.datetime.now()
EXTR_LIA_COV = 130.00
GLAS_LIA_COV = 86.00
LON_CAR_COV = 58.00
HST_RATE = .15
PROC_FEE = 39.99


TodayDsp = Today.strftime("%Y-%m-%d")
print()
print("One Stop Insurance Company")
print(f"Policy listing as of    {TodayDsp:>9s}")
print()
print("POLICY CUSTOMER            TOTAL                    Total       Monthly")
print("NUMBER NAME               PREMIUM       HST         COST        Payment")
print("=======================================================================")

PolicyCtr = 0
TotPremAcc = 0
HSTAcc = 0
TotCosAcc = 0
MonPayAcc = 0

f = open("Policies.dat","r")
for PoliciesDataLine in f:
    PolicyLine = PoliciesDataLine.split(",")
    PolicyNum = int(PolicyLine[0].strip())
    CustFirst = PolicyLine[1].strip()
    CustLast = PolicyLine[2].strip()
    NumCar = int(PolicyLine[8].strip())
    ExtraLiab = (PolicyLine[9].strip())
    GlassCov = (PolicyLine[10].strip())
    LoanCar = (PolicyLine[11].strip())
    PayTyp = (PolicyLine[12].strip())
    InsPrem = float(PolicyLine[13].strip())

    # Calculations go here:
    Full = CustFirst + " " + CustLast
    ExtraCosCTR = 0
    if ExtraLiab == "Y":
        ExtraLiabAmt = NumCar * EXTR_LIA_COV
        ExtraCosCTR += ExtraLiabAmt
    if GlassCov == "Y":
        GlassCovAmt = NumCar * GLAS_LIA_COV
        ExtraCosCTR += GlassCovAmt
    if LoanCar == "Y":
        LoanCarAmt = NumCar * LON_CAR_COV
        ExtraCosCTR += LoanCarAmt
    TotPrem = InsPrem + ExtraCosCTR
    HST = HST_RATE * TotPrem
    TotalCost = TotPrem + HST
    MonthlyPay =(TotalCost + PROC_FEE) / 12
    ExtraCosCTR = ExtraCosCTR
    if PayTyp == "M":
        print(f"{PolicyNum:<4d} {Full:<20s} {FV.FDollar2(TotPrem):<9s}   {FV.FDollar2(HST):<9s}   {FV.FDollar2(TotalCost):>9s}    {FV.FDollar2(MonthlyPay):<10s}")

        # Increment Ctr's and Acc's
        PolicyCtr += 1
        TotPremAcc += TotPrem
        HSTAcc += HST
        TotCosAcc += TotalCost
        MonPayAcc += MonthlyPay
f.close()

print("=======================================================================")
print(f"Total Policies: {PolicyCtr:>3d}      {FV.FDollar2(TotPremAcc):>10s} {FV.FDollar2(HSTAcc):>10s}   {FV.FDollar2(TotalCost)}  {FV.FDollar2(MonPayAcc):>10s}")