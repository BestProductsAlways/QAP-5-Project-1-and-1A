# TO BE A PRO--START PLANNING LIKE A PRO
# Raymond Payne
# QAP 5 Detailed Report
# April 02 2023

import FormatValues as FV
import datetime

Today = datetime.datetime.now()
EXTR_LIA_COV = 130.00
GLAS_LIA_COV = 86.00
LON_CAR_COV = 58.00
HST_RATE = .15
PROC_FEE = 39.99


TodayDsp = Today.strftime("%Y-%m-%d")
print()
print("One Stop Insurance Company")
print(f"Policy listing as of    {TodayDsp:>9s}")
print()
print("POLICY CUSTOMER              INSURANCE     EXTRA      TOTAL")
print("NUMBER NAME                   PREMIUM      COST      PREMIUM")
print("=============================================================")

PolicyCtr = 0
InsPremAcc = 0
ExtCosAcc = 0
TotPremAcc = 0

f = open("Policies.dat","r")
for PoliciesDataLine in f:
    PolicyLine = PoliciesDataLine.split(",")

    PolicyNum = int(PolicyLine[0].strip())
    CustFirst = PolicyLine[1].strip()
    CustLast = PolicyLine[2].strip()
    NumCar = int(PolicyLine[8].strip())
    ExtraLiab = (PolicyLine[9].strip())
    GlassCov = (PolicyLine[10].strip())
    LoanCar = (PolicyLine[11].strip())
    PayTyp = (PolicyLine[12].strip())
    InsPrem = float(PolicyLine[13].strip())

    # Calculations go here
    ExtraCosCTR = 0
    if ExtraLiab == "Y":
        ExtraLiabAmt = NumCar * EXTR_LIA_COV
        ExtraCosCTR += ExtraLiabAmt
    if GlassCov == "Y":
        GlassCovAmt = NumCar * GLAS_LIA_COV
        ExtraCosCTR += GlassCovAmt
    if LoanCar == "Y":
        LoanCarAmt = NumCar * LON_CAR_COV
        ExtraCosCTR += LoanCarAmt
    TotPrem = InsPrem + ExtraCosCTR
    ExtraCosCTR = ExtraCosCTR

    Full = CustFirst + " " + CustLast
    # Print the detail line:
    print(f" {PolicyNum:<4d}  {Full:<20s}  {FV.FDollar2(InsPrem):<9s}   {FV.FDollar2(ExtraCosCTR):<9s}  {FV.FDollar2(TotPrem):<10s} ")
    # Increment Ctr's and Acc's
    PolicyCtr += 1
    InsPremAcc += InsPrem
    ExtCosAcc += ExtraCosCTR
    TotPremAcc += TotPrem

f.close()

print("=============================================================")
print(f"Total Policies: {PolicyCtr:>3d}         {FV.FDollar2(InsPremAcc):>10s}  {FV.FDollar2(ExtCosAcc):>10s} {FV.FDollar2(TotPremAcc):>10s}")
